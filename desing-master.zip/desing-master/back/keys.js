const db = {
  host: "database-1.cmlwdskqtfdl.us-east-2.rds.amazonaws.com",
  port: "3306",
  user: "admin",
  password: "L200107325a",
  database: "data",
};

module.exports = { db };
